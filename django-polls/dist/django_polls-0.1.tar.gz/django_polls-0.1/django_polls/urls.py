from django.urls import path

from . import views

app_name = 'django_polls'
urlpatterns = [
    path('', views.IndexView.as_view(), name="index"),
    path('choice/', views.ChoiceView.as_view(), name='choice'),
    path('<int:pk>', views.DetailView.as_view(), name='detail'),
    path('<int:pk>/results/', views.ResultsView.as_view(), name='results'),
    path('<int:question_id>/vote/', views.Vote.as_view(), name='vote' )
]